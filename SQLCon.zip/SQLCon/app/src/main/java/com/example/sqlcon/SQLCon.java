package com.example.sqlcon;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
//import android.support.annotation.Nullable;
import android.util.Log;
// SQLCon.java class
// first step - extend SQLiteOpenHelper
// second step - going to import SQLiteOpenHelper automarically
// Third step - implement 2 methods - onCreate and onUpgrade
// 4th step - create parent class constructor
// fifth step - delete all arguments from constructor acept contet ,factory and vesion)
// 6th step - create 2 static variables - final DBNAMME and Version and given them vales
// 7th step - replace super arguments with step 6 variables
// 8th step = create SQLiteDatabase object - DB
//9th step - inside SQLcon constructor - DB = getWritableDatabase();
// 10th step - create table insikde onCreate() method
// 11TH STEP  - execute the  query using SQLiteDatabase obkect = DB
// 12th Step - Create Log.d under execute the  query to see the log
// 13th step - in maian activity create instance of SQLCon class

public class SQLCon extends SQLiteOpenHelper {

    public static final String DBNAME = "unidb.db";
    public static int Ver = 1;

    SQLiteDatabase DB;
    public SQLCon(Context context) {
        super(context, DBNAME, null, Ver);
        DB = getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase DB) {
        final String CreateUserTable = "CREATE TABLE IF NOT EXISTS "
                + ContractSQL.Users.Table_Name + "("
                + ContractSQL.Users.ID + " INTEGER PRIMARY KEY, "
                + ContractSQL.Users.FN + " VARCHAR(25), "
                + ContractSQL.Users.SN + " VARCHAR(20), "
                + ContractSQL.Users.EM + " VARCHAR(20), "
                + ContractSQL.Users.USER_GROUP + " VARCHAR(30), "
                + ContractSQL.Users.PW + " VARCHAR(20));";
        // 11TH STEP  - execute the  query using SQLiteDatabase object = DB
        DB.execSQL(CreateUserTable);
        Log.d("CreateUserTableTag", CreateUserTable );
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}



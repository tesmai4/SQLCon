package com.example.sqlcon;

public final class ContractSQL {

    // first step - define  private  constructor
    private ContractSQL()
    {

    }
    //second step - create inner classes for each table
    public static class Users
    {
        public static final String Table_Name = "Users";
        public static final String ID = "id";
        public static final String FN = "fn";
        public static final String SN = "sn";
        public static final String USER_GROUP = "user_grp";// user group
        public static final String PW = "pw";
        public static final String EM = "EM";
        //;
    }
    // create more inner classes here for each table as did in step 2
}

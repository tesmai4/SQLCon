package com.example.sqlcon;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 12th step - in main activity create instance of SQLCon class
        SQLCon sqlcon = new SQLCon(this);

    }

}